//
//  MyFramework.h
//  MyFramework
//
//  Created by Lagarde Quentin on 08/01/2015.
//  Copyright (c) 2015 Lagarde Quentin. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MyFramework.
FOUNDATION_EXPORT double MyFrameworkVersionNumber;

//! Project version string for MyFramework.
FOUNDATION_EXPORT const unsigned char MyFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyFramework/PublicHeader.h>


#import <MyFramework/MyTextfield.h>